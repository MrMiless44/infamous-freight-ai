import PricingTable from '../components/PricingTable';

export default function Pricing() {
  return <PricingTable />;
}
