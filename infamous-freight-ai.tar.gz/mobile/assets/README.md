# Assets Placeholder

Add Expo icon/adaptive-icon/favicon assets here before publishing builds.
